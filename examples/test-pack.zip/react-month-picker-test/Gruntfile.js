"use strict";

const path = require('path')
process.traceDeprecation = true

module.exports = function(grunt) {
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json')
        , tag: {
            banner: '/*!\n'
            + ' * <%= pkg.name %>\n'
            + ' * @version <%= pkg.version %>\n'
            + ' */\n'
        }
        , sass: {
            dev: {
                options: {
                    style: 'expanded'
                    , compass: true
                    //, sourcemap: 'none'
                    //for grunt-sass
                    , sourceMap: false
                }
                , files: [
                    {
                        expand: true
                        , cwd: './scss'
                        , src: [ 'demo.scss' ]
                        , dest: './examples'
                        , ext: '.css'
                    }
                ]
            }
        }
        , webpack: {
            demo: {
                entry: {
                    demo: './examples/demo.jsx'
                    //, react: ['react', 'react-dom']
                }
                , output: {
                    path: path.resolve(__dirname, 'examples')
                    , filename: '[name].js'
                    //, library: '[name]'
                    //, libraryTarget: 'commonjs2'
                }
                , resolve: {
                    extensions: ['.js', '.jsx', '.es6']
                    , modules: ["node_modules"]
                }
                , externals: {
                    react: 'React'
                    , 'react-dom': 'ReactDOM'
                    , 'prop-types': 'PropTypes'
                }
                , module: {
                    loaders: [{
                        test: [/\.jsx$/, /\.es6$/]
                        , exclude: [path.resolve(__dirname, 'node_modules')]
                        , loader: 'babel-loader'
                        , options: {
                            comments: false
                            , sourceMaps: true
                            //, modules: 'umd'
                        }
                    }]
                }
                //, watch: true
                , target: 'web'
                , plugins: []
            }
        }
    })

    grunt.loadNpmTasks('grunt-sass')
    grunt.loadNpmTasks('grunt-webpack')


    grunt.registerTask('default', ['sass:dev', 'webpack:demo'])
    grunt.registerTask('wp', ['webpack:demo'])

}